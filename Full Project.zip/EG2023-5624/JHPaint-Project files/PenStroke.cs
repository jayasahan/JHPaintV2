﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;

public class PenStroke : Shape
{
    private List<Point> _points = new List<Point>();

   
    public PenStroke() { }

    public PenStroke(Point start, Color color, float width)
       
        : base(start, Color.Transparent, color, width)
    {
        _points.Add(start);
    }

    public void AddPoint(Point point)
    {
        _points.Add(point);
    }

    public override void Draw(Graphics g)
    {
        if (_points.Count > 1)
        {
            using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
            {
                g.DrawLines(pen, _points.ToArray());
            }
        }
    }

   
    public override bool Contains(Point p)
    {
        return false;
    }
}