﻿using System.Drawing;

public class RectangleShape : Shape
{
    
    public RectangleShape() { }

    public RectangleShape(Point start, Color fillColor, Color borderColor, float borderWidth)
        : base(start, fillColor, borderColor, borderWidth) { }

    public override void Draw(Graphics g)
    {
        
        using (SolidBrush brush = new SolidBrush(this.FillColor))
        {
            g.FillRectangle(brush, this.Bounds);
        }

         
        using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
        {
            g.DrawRectangle(pen, this.Bounds);
        }
    }
}