using System.Drawing;
using System.Xml.Serialization;


[XmlInclude(typeof(RectangleShape))]
[XmlInclude(typeof(EllipseShape))]
[XmlInclude(typeof(TriangleShape))]
[XmlInclude(typeof(PenStroke))]
public abstract class Shape
{
    public Point StartPoint { get; set; }
    public Point EndPoint { get; set; }
    public Color FillColor { get; set; }
    public Color BorderColor { get; set; }
    public float BorderWidth { get; set; }

   
    public Rectangle Bounds
    {
        get
        {
            return new Rectangle(
                Math.Min(StartPoint.X, EndPoint.X),
                Math.Min(StartPoint.Y, EndPoint.Y),
                Math.Abs(StartPoint.X - EndPoint.X),
                Math.Abs(StartPoint.Y - EndPoint.Y));
        }
    }

    
    public Shape() { }

    protected Shape(Point start, Color fillColor, Color borderColor, float borderWidth)
    {
        StartPoint = start;
        EndPoint = start; 
        FillColor = fillColor;
        BorderColor = borderColor;
        BorderWidth = borderWidth;
    }

    
    public abstract void Draw(Graphics g);

    
    public virtual bool Contains(Point p)
    {
        return Bounds.Contains(p);
    }
}