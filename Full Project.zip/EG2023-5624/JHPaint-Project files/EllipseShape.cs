﻿using System.Drawing;

public class EllipseShape : Shape
{
    
    public EllipseShape() { }

    public EllipseShape(Point start, Color fillColor, Color borderColor, float borderWidth)
        : base(start, fillColor, borderColor, borderWidth) { }

    public override void Draw(Graphics g)
    {
        
        using (SolidBrush brush = new SolidBrush(this.FillColor))
        {
            g.FillEllipse(brush, this.Bounds);
        }
        
        using (Pen pen = new Pen(this.BorderColor, this.BorderWidth))
        {
            g.DrawEllipse(pen, this.Bounds);
        }
    }
}